<?php

namespace AIO_WooDiscount;

use AIO_WooDiscount\Traits\SingletonTrait;
use AIO_WooDiscount\Admin\Menu;
use AIO_WooDiscount\Assets;
use AIO_WooDiscount\Ajax\Checkout_Ajax_Handler;
use AIO_WooDiscount\Ajax\TriggerCart;
use AIO_WooDiscount\Discount\Manager\CouponDisplay;
use AIO_WooDiscount\Discount\Manager\Bogo_Free_Item_Handler;
use AIO_WooDiscount\Discount\Manager\FlatPercentage_Validator;


/**
 * Plugin Functions Installer Class
 */
class Installer
{


    use SingletonTrait;

    /**
     * Class Constructor 
     */
    public function __construct()
    {
        Assets::instance();

        if (is_admin()) {
            Menu::instance();
        }
        FlatPercentage_Validator::instance();
        CouponDisplay::instance();
        Checkout_Ajax_Handler::instance();
        new TriggerCart();
        new Bogo_Free_Item_Handler();
    }
}
