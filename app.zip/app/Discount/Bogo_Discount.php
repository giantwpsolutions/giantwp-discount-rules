<?php

namespace AIO_WooDiscount\Discount;

use AIO_WooDiscount\Discount\Condition\Conditions;
use AIO_WooDiscount\Discount\BogoBuyProduct\BogoBuy_Field;
use AIO_WooDiscount\Discount\BogoBuyProduct\BogoBuyProduct;

class Bogo_Discount
{
    public function __construct()
    {
        add_action('woocommerce_cart_loaded_from_session', [$this, 'maybe_apply_discount']);
    }

    public function maybe_apply_discount()
    {
        if (is_admin() && !defined('DOING_AJAX')) return;
        if (!WC()->cart || WC()->cart->is_empty()) return;

        $rules = $this->get_discount_rules();
        if (empty($rules)) return;

        $matched = false;
        $cart_items = WC()->cart->get_cart();

        foreach ($rules as $rule) {
            if (
                !isset($rule['discountType']) ||
                strtolower($rule['discountType']) !== 'bogo' ||
                ($rule['status'] ?? '') !== 'on'
            ) continue;

            if (!$this->is_schedule_active($rule)) continue;
            if (!$this->check_usage_limit($rule)) continue;

            if (
                isset($rule['enableConditions']) && $rule['enableConditions'] &&
                !Conditions::check_all(WC()->cart, $rule['conditions'], $rule['conditionsApplies'] ?? 'all')
            ) continue;

            if (!BogoBuyProduct::check_all(WC()->cart, $rule['buyProduct'] ?? [], $rule['bogoApplies'] ?? 'all')) {
                continue;
            }

            // Remove previous free items added by this rule
            $this->remove_bogo_items($rule['id']);

            $discount_value   = floatval($rule['discountValue'] ?? 0);
            $max_value        = isset($rule['maxValue']) ? floatval($rule['maxValue']) : null;
            $discount_type    = $rule['discounttypeBogo'] ?? 'fixed';
            $free_or_discount = $rule['freeOrDiscount'] ?? 'free';
            $is_repeat        = $rule['isRepeat'] ?? false;

            $buy_count      = intval($rule['buyProductCount'] ?? 1);
            $get_count      = intval($rule['getProductCount'] ?? 1);
            $total_eligible = $this->count_eligible_items($cart_items, $rule['buyProduct']);

            $repeat_times = $is_repeat ? floor($total_eligible / $buy_count) : ($total_eligible >= $buy_count ? 1 : 0);

            if ($repeat_times <= 0) continue;

            $eligible_products = $this->get_eligible_products($cart_items, $rule['buyProduct']);
            usort($eligible_products, function ($a, $b) {
                return $a['line_subtotal'] <=> $b['line_subtotal'];
            });

            $count_to_add = min(count($eligible_products), $get_count * $repeat_times);
            $added = 0;

            foreach ($eligible_products as $item) {
                $product_id = $item['product_id'];
                $variation_id = $item['variation_id'] ?? 0;

                $cart_item_data = [
                    'is_bogo_extra' => true,
                    'aio_bogo_rule_id' => $rule['id'],
                ];

                if ($free_or_discount === 'free') {
                    $cart_item_data['override_price'] = 0;
                } else {
                    $item_price = $item['line_subtotal'] / max(1, $item['quantity']);
                    $discounted = ($discount_type === 'percentage')
                        ? $item_price * (1 - $discount_value / 100)
                        : max(0, $item_price - $discount_value);

                    $cart_item_data['override_price'] = $discounted;
                }

                WC()->cart->add_to_cart($product_id, 1, $variation_id, [], $cart_item_data);

                $added++;
                if ($added >= $count_to_add) break;
            }

            $matched = true;
            break;
        }

        if (!$matched) {
            $this->remove_all_bogo_items();
        }
    }

    private function count_eligible_items($cart_items, $buy_conditions): int
    {
        $count = 0;
        foreach ($cart_items as $item) {
            if (!empty($item['is_bogo_extra'])) continue;

            foreach ($buy_conditions as $condition) {
                $field = $condition['field'] ?? '';
                if (method_exists(BogoBuy_Field::class, $field) && BogoBuy_Field::$field([$item], $condition)) {
                    $count += $item['quantity'] ?? 0;
                    break;
                }
            }
        }
        return $count;
    }

    private function get_eligible_products($cart_items, $buy_conditions): array
    {
        $eligible = [];
        foreach ($cart_items as $item) {
            if (!empty($item['is_bogo_extra'])) continue;

            foreach ($buy_conditions as $condition) {
                $field = $condition['field'] ?? '';
                if (method_exists(BogoBuy_Field::class, $field) && BogoBuy_Field::$field([$item], $condition)) {
                    $eligible[] = $item;
                    break;
                }
            }
        }
        return $eligible;
    }

    private function remove_bogo_items($rule_id)
    {
        foreach (WC()->cart->get_cart() as $key => $item) {
            if (!empty($item['is_bogo_extra']) && ($item['aio_bogo_rule_id'] ?? '') === $rule_id) {
                WC()->cart->remove_cart_item($key);
            }
        }
    }

    private function remove_all_bogo_items()
    {
        foreach (WC()->cart->get_cart() as $key => $item) {
            if (!empty($item['is_bogo_extra'])) {
                WC()->cart->remove_cart_item($key);
            }
        }
    }

    private function get_discount_rules(): array
    {
        return maybe_unserialize(get_option('aio_bogo_discount', [])) ?: [];
    }

    private function is_schedule_active($rule): bool
    {
        if (!isset($rule['schedule']['enableSchedule']) || !$rule['schedule']['enableSchedule']) {
            return true;
        }

        $now = current_time('timestamp');
        $start = strtotime($rule['schedule']['startDate'] ?? '');
        $end = strtotime($rule['schedule']['endDate'] ?? '');

        return ($now >= $start && $now <= $end);
    }

    private function check_usage_limit($rule): bool
    {
        if (!isset($rule['usageLimits']['enableUsage']) || !$rule['usageLimits']['enableUsage']) {
            return true;
        }

        $limit = intval($rule['usageLimits']['usageLimitsCount'] ?? 0);
        $used = intval($rule['usedCount'] ?? 0);

        return $used < $limit;
    }
}
