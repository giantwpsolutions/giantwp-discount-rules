<?php

namespace AIO_WooDiscount\Discount\Manager;

defined('ABSPATH') || exit;

class Bogo_Free_Item_Handler
{

    public function __construct()
    {
        add_filter('woocommerce_cart_item_price', function ($price_html, $cart_item, $cart_item_key) {
            if (!empty($cart_item['aio_bogo_free_item'])) {
                return '<span class="aio-free-price">' . esc_html__('Free', 'aio-woodiscount') . '</span>';
            }
            return $price_html;
        }, 10, 3);

        // Show "Free" label on subtotal field
        add_filter('woocommerce_cart_item_subtotal', function ($subtotal_html, $cart_item, $cart_item_key) {
            if (!empty($cart_item['aio_bogo_free_item'])) {
                return '<span class="aio-free-subtotal">' . esc_html__('Free', 'aio-woodiscount') . '</span>';
            }
            return $subtotal_html;
        }, 10, 3);

        // Ensure free items do not affect cart total
        add_action('woocommerce_before_calculate_totals', function ($cart) {
            if (is_admin() && !defined('DOING_AJAX')) return;

            foreach ($cart->get_cart() as $cart_item_key => &$cart_item) {
                if (!empty($cart_item['aio_bogo_free_item'])) {
                    $cart_item['data']->set_price(0);
                }
            }
        }, 20);
    }
}
